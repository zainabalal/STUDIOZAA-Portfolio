/*---------------------------------------------------------
* Template Name    : New Jungle | Responsive Personal Template
* Author           : CasanovasThemes
* Version          : 1.0.0
* Created          : July 2020
* File Description : Main Js file of the template
*----------------------------------------------------------
*/
// Whole-script strict mode syntax
"use strict";
document.addEventListener("DOMContentLoaded", function(event) {
  /***************************
  PAGE LOADER FADE
  ****************************/
  window.onload = function() {
    document.getElementById("loader-wrap").style.visibility = "hidden";
    document.getElementById("loader-wrap").style.opacity = "0";
    document.getElementById("loader-wrap").style.transition = "1s";
    //$("body").css({"overflow":"auto"});
  };
  /**/
  msieversion();
  heightHome();
  var sectionOpen = false;
  var firstTime = 0;
  var intervalInner;
  var prev = document.getElementsByClassName("prev");
  var next = document.getElementsByClassName("next");
  var workOpen;
  var blockOpen;

  /***************************
  CLIENTS - OWLCAROUSEL
  ****************************/
  $('.owl-carousel').owlCarousel({
    loop:true,
    margin:50,
    nav:false,
    dotsEach:true,
    responsiveClass:true,
    responsive:{
        0:{
            items:1,
        },
        600:{
            items:1,
        },
        1000:{
            items:2,
            loop:false
        }
    }
  })

  /***************************
  CALCULATE THE HEIGHT
  ****************************/
  function heightHome(){
    var height_screen = window.innerHeight;   
    document.getElementById("home").style.height = height_screen+"px";
    document.getElementById("list-nav").style.height = height_screen+"px"; 
    
    for (var i = 0; i < document.getElementsByClassName("container-section").length; i++) {
        document.getElementsByClassName("container-section")[i].style.height = height_screen+"px";   
    }
  }
  /***************************
  CALL FUNCTIONS
  ****************************/
  //Transition skills - width bar-inner:
  if (document.getElementById("about")) {
    document.getElementById("about").addEventListener('scroll', function() {
      skillsAnimation();
    }, true);
  }
  loadBlog();
  /***************************
  ADDEVENTLISTENERS
  ****************************/
  /****RESIZE****/
  window.addEventListener('resize', function() {
    heightHome();
    disableTransitionsOnResize();
  }, true);
  window.addEventListener('orientationchange', function() {
    heightHome();
    disableTransitionsOnResize();
  }, true);
  /****OPEN MENU****/
  document.getElementById("topnav-menu").addEventListener('mouseover', function() {
    if (sectionOpen == false) {
      openMenuTopNav();
      document.getElementById("bar1").classList.remove('longBar');
    }
  }, true);
  /****CLOSE MENU****/
  document.getElementById("home").addEventListener('mouseover', function() {
    closeMenuTopNav();
    if (sectionOpen == false) {
      document.getElementById("bar1").classList.add('longBar');
    }
  }, true);
  document.getElementById("projector").addEventListener('mouseover', function() {
    closeMenuTopNav();
    if (sectionOpen == false) {
      document.getElementById("bar1").classList.add('longBar');
    }
  }, true);
  /**CLOSE BLOG OR WORK***/
  document.getElementById("close").addEventListener("click", closeblogPopUp);
 

  /****OPEN SECTION****/
  for (var i = 0; i < document.getElementsByClassName("li-list").length; i++) {
    document.getElementsByClassName("li-list")[i].addEventListener('click', function() {
      var sectionName = this.getAttribute('data-value');
      if (sectionOpen == false) {
        closeMenuTopNav();
        sectionOpen = true;
        setTimeout(function() {
          document.getElementById("topnav-menu").classList.add('animate');
          if (document.getElementById(sectionName)) {
            document.getElementById(sectionName).classList.add("openSection");
          }
          if (document.getElementById('projector')) {
            document.getElementById('projector').style.background = "#24272a";
            setTimeout(function() {
              document.getElementById("projector").style.zIndex = "6";
            }, 200);
          }
        }, 300);
      }
    }, true);
  }

  /****CLOSE ALL SECTIONS****/
  document.getElementById("topnav-menu").addEventListener('click', function() {
    if (sectionOpen === true) {
      document.getElementById("topnav-menu").classList.remove('animate');
      for (var i = 0; i < document.getElementsByClassName("sections").length; i++) {
        document.getElementsByClassName("sections")[i].classList.remove("openSection");
        if (document.getElementById('projector')) {
          document.getElementById('projector').style.background = "none";
          setTimeout(function() {
            document.getElementById("projector").style.zIndex = "2";
          }, 300);
        }
      }
      setTimeout(function() {
        for (var i = 0; i < document.getElementsByClassName("container-section").length; i++) {
          document.getElementsByClassName("container-section")[i].scrollTop = 0;
        }
      }, 800);
      openMenuTopNav();
      sectionOpen = false;
    }
  }, true);
  /****HOVER LIST NAV LI****/
  for (var i = 0; i < document.getElementsByClassName("li-list").length; i++) {
    document.getElementsByClassName("li-list")[i].addEventListener('mouseover', function() {
      this.classList.add("main-color");
    }, true);
  }
  for (var i = 0; i < document.getElementsByClassName("li-list").length; i++) {
    document.getElementsByClassName("li-list")[i].addEventListener('mouseout', function() {
      this.classList.remove("main-color"); 
    }, true);
  }
  /****HOVER SOCIAL MEDIA ICONS****/
  for (var i = 0; i < document.getElementsByClassName("social-media").length; i++) {
    document.getElementsByClassName("social-media")[i].addEventListener('mouseover', function() {
      this.firstChild.classList.add("main-color");
    }, true);
  }
  for (var i = 0; i < document.getElementsByClassName("social-media").length; i++) {
    document.getElementsByClassName("social-media")[i].addEventListener('mouseout', function() {
      this.firstChild.classList.remove("main-color"); 
    }, true);
  }
  
  document.getElementById("topnav-menu").addEventListener('mouseover', function() {
    if(sectionOpen == true){
      this.style.cursor = "pointer";
    }else{
      this.style.cursor = "auto";
    }
  }, true);


  /***************************
  FUNCTIONS
  ****************************/
  function disableTransitionsOnResize() { 
    const classes = document.body.classList;
    let timer = 0;
    window.addEventListener('resize', function () {
        if (timer) {
          clearTimeout(timer);
          timer = null;
        }
        else{
          classes.add('stop-transitions');
          for (var i = 0; i < document.getElementsByClassName("sections").length; i++) {
            document.getElementsByClassName("sections")[i].classList.add('stop-transitions');
          }
        }
        timer = setTimeout(function() {
          classes.remove('stop-transitions');
          for (var i = 0; i < document.getElementsByClassName("sections").length; i++) {
            document.getElementsByClassName("sections")[i].classList.remove('stop-transitions');
          }
          timer = null;
        }, 100);
    });
  }
  function openMenuTopNav(){
    document.getElementById("list-nav").classList.add("list-nav-open");
  }
  function closeMenuTopNav(){
    document.getElementById("list-nav").classList.remove("list-nav-open");
  }
  /***************************
  SKILLS BAR ANIMATION
  ****************************/
  function skillsAnimation(){
    var height_skills = document.getElementById("skills");

    var lengthTitleSections = document.getElementsByClassName("span-wrapper").length;
    if (isElementInViewport(height_skills)) {  
      firstTime++;
      onetime();
      document.getElementsByClassName("bar-inner")[0].style.width = "90%";
      document.getElementsByClassName("bar-inner")[1].style.width = "95%";
      document.getElementsByClassName("bar-inner")[2].style.width = "70%";
      document.getElementsByClassName("bar-inner")[3].style.width = "80%";
      document.getElementsByClassName("bar-inner")[4].style.width = "75%";      
      document.getElementsByClassName("bar-inner")[5].style.width = "85%";
      
    }
  }
  function onetime(){
    //number percentage:
    if (firstTime <= 1) {
      intervalInner = setInterval(function(){
        var percentage_0 = new Array(6);
        for (var i = 0; i < 6; i++) {
          percentage_0[i] = (document.getElementsByClassName("bar-inner")[i].offsetWidth / document.getElementsByClassName("bar-inner")[i].parentElement.offsetWidth) * 100;
          document.getElementsByClassName("bar-value")[i].innerHTML = Math.round(percentage_0[i]) + "%";
        }
      }, 50);
    }
  }
  /***************************
  Check if an element is in viewport
  ****************************/
  function isElementInViewport(el) {
    const rect = el.getBoundingClientRect();
    // DOMRect { x: 8, y: 8, width: 100, height: 100, top: 8, right: 108, bottom: 108, left: 8 }
    const windowHeight = (window.innerHeight || document.documentElement.clientHeight);
    const windowWidth = (window.innerWidth || document.documentElement.clientWidth);

    // http://stackoverflow.com/questions/325933/determine-whether-two-date-ranges-overlap
    const vertInView = (rect.top <= windowHeight) && ((rect.top + rect.height) >= 0);
    const horInView = (rect.left <= windowWidth) && ((rect.left + rect.width) >= 0);

    return (vertInView && horInView);
  }
  

  /***************************
  BUTTON ON HOVER
  ****************************/ 
  $('.btn-casan')
    .on('mouseenter', function(e) {
      var parentOffset = $(this).offset(),
          relX = e.pageX - parentOffset.left,
          relY = e.pageY - parentOffset.top;
      $(this).find('span').css({top:relY, left:relX})
    })
    .on('mouseout', function(e) {
      var parentOffset = $(this).offset(),
          relX = e.pageX - parentOffset.left,
          relY = e.pageY - parentOffset.top;
      $(this).find('span').css({top:relY, left:relX})
    });

  /***************************
  DETECT EXPLORER
  ****************************/ 
  /*Detect the browser and if is explorer asign file css*/
  function msieversion(){
    var ua = window.navigator.userAgent;
    var isIE = /MSIE|Trident/.test(ua);

    if ( isIE ) {
      //IE specific code goes here
      var lengthCol = document.getElementsByClassName("col").length;
      var link=document.createElement('link');
      link.type="text/css";
      link.rel="stylesheet";
      link.href="css/explorer.css";
      document.getElementsByTagName('head')[0].appendChild(link);
    }else{
      //Other Browser
    }
  }

  /***************************
  ISOTOPE OPTIONS WORK
  ****************************/
  $('.filters ul li').on("click", function() {
    $('.filters ul li').removeClass('activeLiWork');
    $(this).addClass('activeLiWork');
    
    var data = $(this).attr('data-filter');
    $grid.isotope({
      filter: data
    })
  });
  var $grid = $('.grid').imagesLoaded( function() {
    $('.grid').isotope({
      layoutMode : 'fitRows'
    });
  });
  /***************************
  POP-UP WORK
  ****************************/
  onclickWork();
  function flexBlock(){
    workOpen = 1;
    if (window.innerWidth <= 1050) {
      document.getElementById("pop-up-blog").style.display = "block";
      document.getElementById("pop-up-blog").style.visibility = "visible";
      document.getElementById("pop-up-blog").style.opacity = "1";
    }else if (window.innerWidth > 1050) {
      document.getElementById("pop-up-blog").style.display = "flex";
      document.getElementById("pop-up-blog").style.visibility = "visible";
      document.getElementById("pop-up-blog").style.opacity = "1";
    }
  }
  function onclickWork(){
    var $tests = $(".item").on("click",function (e) {
      if (document.getElementById('projector')) {
        document.getElementById("projector").style.zIndex = "99991";
      }
      var nFirstWork = $tests.index(this);
      console.log("first work; " + nFirstWork);
      flexBlock();

      var lengthContentWork = document.getElementsByClassName("contentWork").length;
      for (var i = 0; i < lengthContentWork; i++) {
        document.getElementsByClassName("contentWork")[i].style.display = "block";
      }
      //body overflow hidden:
      document.getElementsByTagName("BODY")[0].style.overflow = "hidden";

      var divContent = e.target.parentElement.firstElementChild;

      document.getElementById("inner-popUp").innerHTML = document.getElementsByClassName("contentWork")[nFirstWork].innerHTML;
      /*Create addEventListener of the buttons Prev and Next:*/

      for (var i = 0; i < prev.length; i++) {
        prev[i].addEventListener("click", function() {
          nextWork(nFirstWork, -1);
        });
      }
      for (var i = 0; i < next.length; i++) {
        next[i].addEventListener("click", function() {
          nextWork(nFirstWork, 1);
        });
      }
    });
  }
  /*Slide Pop-up blog and Work*/
  function nextWork(nOldWork, n){
    document.getElementById('pop-up-blog').scrollTop = 0;
    var nActualWork = nOldWork + n;
    if (nActualWork > next.length - 2) {
      nActualWork = 0;
    } else if (nActualWork < 0) {
      nActualWork = next.length - 2;
    }
    document.getElementById("inner-popUp").innerHTML = document.getElementsByClassName("contentWork")[nActualWork].innerHTML;
    /*Create addEventListener of the buttons Prev and Next:*/
    for (var i = 0; i < prev.length; i++) {
      prev[i].addEventListener("click", function() {
        nextWork(nActualWork, -1);
      });
    }
    for (var i = 0; i < next.length; i++) {
      next[i].addEventListener("click", function() {
        nextWork(nActualWork, 1);
      });
    }
    console.log("Old work; " + nOldWork);
    console.log("actual work; " + nActualWork);
  }
  window.addEventListener('resize', function() {
    if (workOpen == 1) {
      flexBlock();
    }
  }, true);
  /***************************
  POP-UP BLOG
  ****************************/
  if (document.getElementById("pop-up-blog").style.display == "block" || document.getElementById("pop-up-blog").style.display == "flex") {
    blockOpen = 1;
  }
  else{
    blockOpen = 0;
  }
  function loadBlog(){
    var d;
    var g = 1;
    window.addEventListener('resize', function() {
      nBlogsToShow();
    }, true);
    function nBlogsToShow(){
      itemsForLine();
      for (var i = 0; i < document.getElementsByClassName("blog").length; i++) {
        var x = (document.getElementsByClassName("blog").length - d);
        if(i < x){
          document.getElementsByClassName("blog")[i].style.display = "none";
        }else{
          document.getElementsByClassName("blog")[i].style.display = "block";
        }
      }
      if (x > 0) {//if there are one or more blogs with display none, show link. 
        if (document.getElementById("showLess")) {
          $("#showLess").remove();
        }
        if (document.getElementById("showMore")) {
          $("#showMore").remove();
        }
        var nodeP = document.createElement("A");
        nodeP.setAttribute("id", "showMore");
        nodeP.setAttribute("class", "main-color");
        document.getElementById("markShowMore").appendChild(nodeP);
        document.getElementById("showMore").innerHTML = "Show more";
        document.getElementById("showMore").addEventListener("click", showMoreBlogs);
      }else if (x <= 0) {// if there aren't more blogs to display, remove link
        if (document.getElementById("showMore")) {
          $("#showMore").remove();
        }
      }
    }
    function itemsForLine(){
      if (window.innerWidth <= 700) {
        d = 2;//Show 2
      }else if (window.innerWidth <= 1050){
        d = 4;//Show 2
      }else if (window.innerWidth > 1050) {
        d = 6;//Show 3
      }
      return d;
    }
    /*add the content in the section Blog*/
    var paragraph = [];
    nBlogsToShow();

    function flexBlock(){
      document.getElementById("pop-up-blog").style.display = "block";
      document.getElementById("pop-up-blog").style.visibility = "visible";
      document.getElementById("pop-up-blog").style.opacity = "1";
    }

    var lengthblog = document.getElementsByClassName("blog").length;
    for (var i = 0; i < lengthblog; i++) {
      document.getElementsByClassName("blog")[i].addEventListener("click",function() {
        if (document.getElementById('projector')) {
          document.getElementById("projector").style.zIndex = "999";
        }
          //copy div of the new clicked:
          flexBlock();
          document.getElementById("inner-popUp").innerHTML = this.innerHTML; 
          //body overflow hidden:
          document.getElementsByTagName("BODY")[0].style.overflow = "hidden";
      });
    }
    function showMoreBlogs(){
      itemsForLine();
      var x = (document.getElementsByClassName("blog").length - d);
      if (x - g >= 0) {
        for (var i = 0; i < document.getElementsByClassName("blog").length; i++) {
          if(i == x-g){
            document.getElementsByClassName("blog")[i].style.display = "block";
            g++;
          }
        }
      }
      if (x - g <0) {
        $("#showMore").remove();
      
        var nodeRemove = document.createElement("A");
        nodeRemove.setAttribute("id", "showLess");
        nodeRemove.setAttribute("class", "main-color");
        document.getElementById("markShowMore").appendChild(nodeRemove);
        document.getElementById("showLess").innerHTML = "Show less";
        document.getElementById("showLess").addEventListener("click", function() {
          nBlogsToShow();
          document.getElementById('blog').scrollIntoView();
      });
      }
      if (x - g < 0){
        g = 1;
      }
    }
    window.addEventListener('resize', function() {
      if (blockOpen == 1) {
        flexBlock();
      }
    }, true);
  }

  /***************************
  CLOSE POP-UP WORK AND BLOG
  ****************************/
  function closeblogPopUp(){
    if (document.getElementById('projector')) {
      document.getElementById("projector").style.zIndex = "6";
    }
    workOpen = 0;
    document.getElementById('pop-up-blog').scrollTop = 0;
    setTimeout(function() {
      document.getElementById("pop-up-blog").style.visibility = "hidden";
    }, 200);
    document.getElementById("pop-up-blog").style.opacity = "0";


    //show text 'read more':
    var lengthText = document.getElementsByClassName("text-bold").length;
    for (var i = 0; i < lengthText; i++) {
      document.getElementsByClassName("text-bold")[i].style.display = "block";
    }
    var lengthContentWork = document.getElementsByClassName("contentWork").length;
    for (var i = 0; i < lengthContentWork; i++) {
      document.getElementsByClassName("contentWork")[i].style.display = "none";
    }
  }
  /***************************
  TEXT ANIMATION HOME
  ****************************/
  var TxtRotate = function(el, toRotate, period) {
    this.toRotate = toRotate;
    this.el = el;
    this.loopNum = 0;
    this.period = parseInt(period, 10) || 2000;
    this.txt = '';
    this.tick();
    this.isDeleting = false;
  };

  TxtRotate.prototype.tick = function() {
    var i = this.loopNum % this.toRotate.length;
    var fullTxt = this.toRotate[i];

    if (this.isDeleting) {
      this.txt = fullTxt.substring(0, this.txt.length - 1);
    } else {
      this.txt = fullTxt.substring(0, this.txt.length + 1);
    }

    this.el.innerHTML = '<span class="wrap">'+this.txt+'</span>';

    var that = this;
    var delta = 200 - Math.random() * 100;

    if (this.isDeleting) { delta /= 2; }

    if (!this.isDeleting && this.txt === fullTxt) {
      delta = this.period;
      this.isDeleting = true;
    } else if (this.isDeleting && this.txt === '') {
      this.isDeleting = false;
      this.loopNum++;
      delta = 500;
    }

    setTimeout(function() {
      that.tick();
    }, delta);
  };
  var elements = document.getElementsByClassName('txt-rotate');
  for (var i=0; i<elements.length; i++) {
    var toRotate = elements[i].getAttribute('data-rotate');
    var period = elements[i].getAttribute('data-period');
    if (toRotate) {
      new TxtRotate(elements[i], JSON.parse(toRotate), period);
    }
  }
  // INJECT CSS
  var css = document.createElement("style");
  css.type = "text/css";
  css.innerHTML = ".txt-rotate > .wrap { border-right: 1px solid #FFFFFF; padding-right: 5px; }";
  document.body.appendChild(css);
});