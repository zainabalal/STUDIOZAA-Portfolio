/*---------------------------------------------------------
* Template Name    : New Jungle | Responsive Personal Template
* Author           : CasanovasThemes
* Version          : 1.0.0
* Created          : July 2020
* File Description : Video Js file of the template
*----------------------------------------------------------
*/
"use strict";
document.addEventListener("DOMContentLoaded", function(event) {
	var videoDiv = document.getElementById('home').appendChild(document.createElement('div'));
	var durationVideo;
	videoDiv.setAttribute("id", "myVideo");
	videoDiv.innerHTML += 
		'<video id="video" playsinline muted loop preload="none">' +
			'<source src="images/video.mp4" type="video/mp4">' +
			'Your browser does not support HTML5 video.' +
		'</video>';

    /***************************
	FADE VIDEO
	****************************/
	if(document.getElementById("video")){
		
		var video = document.getElementById("video");
		
		video.muted = true;
		video.setAttribute("playsinline",null);
		video.loop = true;

		setTimeout(function() {
			video.play();
			video.addEventListener('loadedmetadata', function() {
				var durationVideo = video.duration;
				/*Load the video after document was loaded*/
				
				video.style.opacity = 0;
				video.oncanplaythrough = function() {
			        fade(video);
			        if (window.innerWidth > 800) {
						setTimeout(function() {
				        	fadeOut(video);
					    }, durationVideo*1000 - 2000);
					}
				};
			});
		}, 1000);

		function fade(element) {
		    var op = 0;
		    var timer = setInterval(function() {
		        if (op >= 1) clearInterval(timer);
		        element.style.opacity = op;
		        element.style.filter = 'alpha(opacity=' + op * 100 + ")";
		        op += op * 0.1 || 0.1;
		    }, 50);
		}
		function fadeOut(element) {
		    var op = 1;
		    var timer = setInterval(function() {
		        if (op <= 0.1) clearInterval(timer);
		        element.style.opacity = op;
		        element.style.filter = 'alpha(opacity=' + op * 100 + ")";
		        op -= op * 0.1 || 0.1;
		    }, 50);
		}
	}
});

