/*---------------------------------------------------------
* Template Name    : New Jungle | Responsive Personal Template
* Author           : CasanovasThemes
* Version          : 1.0
* Created          : July 2020
* File Description : Ripples Options JS file
*----------------------------------------------------------
*/
$( document ).ready(function() {
	"use strict";
	$(window).resize(function(){
		$("#home").ripples('destroy');
		ripples();
	});
	ripples();
	function ripples(){
		$('#pop-up-blog').append('<div id="ripplesOn"></div>');
		document.getElementById("pop-up-blog").style.backgroundColor = "#24272a";

		$("#home").ripples({
	    	resolution: 1000,
	    	dropRadius: 10,
			perturbance: 0.02,
	    });
		
	}
	if (document.getElementById("ripplesOn")) {
    	document.getElementById("pop-up-blog").style.backgroundColor = "#24272a";
    }else{
    	document.getElementById("pop-up-blog").style.backgroundColor = "transparent";
    }
});