/*---------------------------------------------------------
* Template Name    : New Jungle | Responsive Personal Template
* Author           : CasanovasThemes
* Version          : 1.0.0
* Created          : July 2020
* File Description : Audio Js file of the template
*----------------------------------------------------------
*/
"use strict";
document.addEventListener("DOMContentLoaded", function(event) {
	var playPause;
	var link=document.createElement('link');
	var fAudio;
	var eAudio;
	link.type="text/css";
	link.rel="stylesheet";
	link.href="audio/audio.css";
	
	$('body').append('<audio loop id="audio"><source src="audio/audio.mp3" type="audio/mpeg"></audio>');
	$('body').append( '<div class="wrapperAudio"></div>');
	$('.wrapperAudio').append( '<button type="button" class="site-sound" title="Toggle sound">'
		+   '<div class="rectangle"></div>'
		+	'<div class="rectangle"></div>'
		+	'<div class="rectangle"></div>'
		+	'<div class="rectangle"></div>'
		+	'<div class="rectangle"></div>'
		+	'<div class="rectangle"></div>'
		+	'<div class="rectangle"></div>'
		+ '</button>');

	//autoplay:
	window.addEventListener('load', function(event){
		if (window.innerWidth > 1050) {
			document.getElementById("audio").volume = 0.01;
		}else{
			document.getElementById("audio").volume = 0.1;
		}
    	//Detect if audio is paused
		setTimeout(function() {
			//document.getElementById("audio").play();
			if (document.getElementById("audio").paused === true){
				playPause = 0;
			}else{
				playPause = 1;
				for (var i = 0; i < document.getElementsByClassName("rectangle").length; i++) {
					document.getElementsByClassName("rectangle")[i].classList.add("rectangle-" + i);
				}
			}
		}, 1000);
	});
	document.getElementsByTagName('head')[0].appendChild(link);
	
	if (document.getElementById("audio")){
		document.getElementsByClassName("wrapperAudio")[0].addEventListener("click", audioPlayer);
		function audioPlayer(){
			document.getElementsByClassName("wrapperAudio")[0].removeEventListener("click", audioPlayer);
			playPause++;
			if ( playPause % 2 !== 0 && document.getElementById("audio").paused === true) {
				playAudio();
			}else if (playPause % 2 === 0 && document.getElementById("audio").paused === false){
				//document.getElementById("audio").currentTime = 0;//restart audio
			    pauseAudio();
			}
		}
		function pauseAudio(){
			if (window.innerWidth > 1050) {
		       	if(document.getElementById("audio").volume){
					var setVolume = 0.01;  // Target volume level for old song 
					var speed = 0.005;  // Rate of volume decrease
					fAudio = setInterval(function(){
						document.getElementById("audio").volume -= speed;
						if(document.getElementById("audio").volume <= setVolume){
							clearInterval(fAudio);
							document.getElementById("audio").pause();
							document.getElementsByClassName("wrapperAudio")[0].addEventListener("click", audioPlayer);
						};
					},50);
		       	};
		    }else{
		    	document.getElementById("audio").pause();
		    	document.getElementsByClassName("wrapperAudio")[0].addEventListener("click", audioPlayer);
		    }
			deleteAnimationAudioBar();
		}
		function playAudio(){
			document.getElementById("audio").play();
			if (window.innerWidth > 1050) {
		       	if(document.getElementById("audio").volume){
		          	var setVolume = 0.1; // Target volume level for new song
		          	var speed = 0.005; // Rate of increase
		          	eAudio = setInterval(function(){
			            document.getElementById("audio").volume += speed;
			            if(document.getElementById("audio").volume >= setVolume){
			                clearInterval(eAudio);
							document.getElementsByClassName("wrapperAudio")[0].addEventListener("click", audioPlayer);
			            }else if(document.hidden){
							if ( playPause % 2 !== 0 ) {
								clearInterval(eAudio);
							}
						}
		          	},50);
		       	};
		    }else{
		    	document.getElementsByClassName("wrapperAudio")[0].addEventListener("click", audioPlayer);
		    }
			animationAudioBar();
		}

		function animationAudioBar(){
			for (var i = 0; i < document.getElementsByClassName("rectangle").length; i++) {
				document.getElementsByClassName("rectangle")[i].classList.add("rectangle-" + i);
			}
		}
		function deleteAnimationAudioBar(){
			for (var i = 0; i < document.getElementsByClassName("rectangle").length; i++) {
				document.getElementsByClassName("rectangle")[i].classList.remove("rectangle-" + i);
			}
		}
		document.getElementsByClassName("wrapperAudio")[0].addEventListener("mouseover", function(){
			animationAudioBar();
		});
		document.getElementsByClassName("wrapperAudio")[0].addEventListener("mouseout", function(){
			if ( playPause % 2 === 0 ) {
				deleteAnimationAudioBar();
			}
		});
		document.addEventListener('visibilitychange', function() {
			if(document.hidden){
				if ( playPause % 2 !== 0 ) {
					pauseAudio();
				}
			}
			else{
				if ( playPause % 2 !== 0 ) {
					playAudio();
				}
			}
		});
	}
});